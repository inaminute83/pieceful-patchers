Place your quilt photos in this folder and reference them from gallery.html.
Recommended sizes: 1600x1200 (or larger), JPG, optimized for web.
Example usage in gallery.html:
  <a href="assets/img/your-photo.jpg" class="gallery-item"><img src="assets/img/your-photo.jpg" alt="Quilt Title" /></a>
